"""CLI package for cleanvid."""
