"""
Web dashboard for Cleanvid.

Provides a web interface for monitoring and controlling video processing.
"""

__version__ = "1.0.0"
