"""Data models for cleanvid application."""
